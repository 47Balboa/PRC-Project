<template>
    <Statistics />
</template>

<script>
// @ is an alias to /src
import Statistics from '@/components/Statistics.vue'

export default {
  name: 'Estatisticas',
  components: {
    Statistics
  }
}
</script>
