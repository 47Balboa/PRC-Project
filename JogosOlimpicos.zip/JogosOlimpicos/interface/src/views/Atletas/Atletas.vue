<template>
    <ListaAtletas />
</template>

<script>
// @ is an alias to /src
import ListaAtletas from '@/components/Atletas/ListaAtletas.vue'

export default {
  name: 'Atletas',
  components: {
    ListaAtletas
  }
}
</script>
