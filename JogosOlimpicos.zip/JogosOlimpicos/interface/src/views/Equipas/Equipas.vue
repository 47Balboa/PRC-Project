<template>
    <ListaEquipas/>
</template>

<script>
// @ is an alias to /src
import ListaEquipas from '@/components/Equipas/ListaEquipas.vue'

export default {
  name: 'Equipas',
  components: {
    ListaEquipas
  }
}
</script>
