<template>
    <Rings />
</template>

<script>
// @ is an alias to /src
import Rings from '@/components/About/Rings.vue'

export default {
  name: 'Rings',
  components: {
    Rings
  }
}
</script>
