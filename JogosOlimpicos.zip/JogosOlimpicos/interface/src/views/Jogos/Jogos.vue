<template>
    <ListaJogos/>
</template>

<script>
// @ is an alias to /src
import ListaJogos from '@/components/Jogos/ListaJogos.vue'

export default {
  name: 'Jogos-Olimpicos',
  components: {
    ListaJogos
  }
}
</script>
