<template>
    <PaginaPrincipal />
</template>

<script>
// @ is an alias to /src
import PaginaPrincipal from '@/components/PaginaPrincipal.vue'

export default {
  name: 'Pagina Principal',
  components: {
    PaginaPrincipal
  }
}
</script>
