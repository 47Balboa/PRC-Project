<template>
    <History />
</template>

<script>
// @ is an alias to /src
import History from '@/components/About/History.vue'

export default {
  name: 'History',
  components: {
    History
  }
}
</script>
