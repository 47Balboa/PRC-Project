<template>
    <ListaEventos/>
</template>

<script>
// @ is an alias to /src
import ListaEventos from '@/components/Eventos/ListaEventos.vue'

export default {
  name: 'Eventos',
  components: {
    ListaEventos
  }
}
</script>
